


--PROBLEMA 1: CONCURRENCIA SIN CONTROL  (ACTUALIZACI�N PERDIDA)

USE Laboratorio;

BEGIN TRAN;
-- Segunda transacci�n

SELECT saldo FROM Cuenta WHERE id = 1;
-- Tambi�n lee 1000

UPDATE Cuenta SET saldo = 700 WHERE id = 1;
-- Cambia el saldo sin saber del otro proceso

COMMIT;
-- Guarda el cambio

------------------------------------------------

SELECT * FROM Cuenta;  

-- Resultado incorrecto

--Ambas transacciones leyeron el mismo valor y se sobrescribieron--

------------------------------------------------
--SOLUCI�N 1: Evitar actualizaci�n perdida (UPDLOCK)

--Se usa un bloqueo de actualizaci�n para que nadie m�s modifique el dato.

BEGIN TRAN;
-- Inicia otra transacci�n

SELECT saldo 
FROM Cuenta WITH (UPDLOCK);
-- Intenta bloquear pero debe esperar a que la otra termine

UPDATE Cuenta 
SET saldo = saldo - 300 
WHERE id = 1;
-- Se ejecuta despu�s de la primera

COMMIT;

--Resultado:  Saldo correcto = 500

--El UPDLOCK obliga a que una transacci�n espere a la otra, evitando sobrescrituras.

SELECT * FROM Cuenta;  
----------------------------------------------------------------------------------
-------------------------------------------------------------------------------
--PROBLEMA 2: LECTURA SUCIA

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
-- Permite leer datos no confirmados

SELECT saldo FROM Cuenta WHERE id = 1;
-- Lee 200 (dato temporal)


---Resultado: Se ley� un dato que nunca fue definitivo----


---------------------------------------------------
--SOLUCI�N 2: Evitar lectura sucia (READ COMMITTED)

--No permite leer datos no confirmados.

SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
-- Nivel por defecto: solo lee datos confirmados

SELECT saldo FROM Cuenta WHERE id = 1;
-- Espera hasta que la otra transacci�n haga COMMIT o ROLLBACK


--Resultado:  Nunca se ley� el valor incorrecto
--READ COMMITTED evita leer datos que no est�n confirmados

--------------------------------------------------------
--------------------------------------------------------
---PROBLEMA 3: LECTURA NO REPETIBLE

UPDATE Cuenta SET saldo = 800 WHERE id = 1;
-- Cambia el valor


--Resultado: Consulto dos veces y obtuvo valores diferentes.
------------------------------------------------------------------
-----------------------------------------------------------------
--SOLUCI�N 3: Evitar lectura no repetible (REPEATABLE READ)

-- Mantiene bloqueados los datos le�dos.

UPDATE Cuenta SET saldo = 800 WHERE id = 1;
-- Se queda esperando (no puede modificar)

--Resultado: El valor no cambia dentro de la transacci�n
--REPEATABLE READ asegura que los datos no cambien mientras los est�s usando
---------------------------------------------------------
---------------------------------------------------

--PROBLEMA 4: DEADLOCK

BEGIN TRAN;
-- Inicia otra transacci�n

UPDATE Cuenta SET saldo = saldo - 200 WHERE id = 2;
-- Bloquea fila 2

WAITFOR DELAY '00:00:08';
-- Espera

UPDATE Cuenta SET saldo = saldo - 30 WHERE id = 1;
-- Intenta acceder a fila 1

------------------------------------------------------
--SQL Server muestra error de deadlock
--Cada transacci�n tiene un recurso y espera el otro. El sistema cancela una


--------------------------------------------------
--SOLUCI�N 4: Evitar deadlock (orden consistente)

--La clave es acceder a los datos en el mismo orden.

BEGIN TRAN;

UPDATE Cuenta SET saldo = saldo - 200 WHERE id = 1;
-- MISMO ORDEN: primero cuenta 1

WAITFOR DELAY '00:00:08';

UPDATE Cuenta SET saldo = saldo - 30 WHERE id = 2;
-- Luego cuenta 2

COMMIT;

--Resultado: No hay deadlock
--Si todas las transacciones acceden en el mismo orden, se evita el bloqueo mutuo







