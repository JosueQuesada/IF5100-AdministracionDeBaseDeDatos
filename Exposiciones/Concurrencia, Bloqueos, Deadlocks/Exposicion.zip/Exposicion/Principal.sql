

CREATE DATABASE Laboratorio;

GO

USE Laboratorio;


CREATE TABLE Cuenta (
    id INT PRIMARY KEY,   
    saldo INT             
);

INSERT INTO Cuenta VALUES (1, 1000);
-- Inserta saldo inicial



select * from Cuenta; 






