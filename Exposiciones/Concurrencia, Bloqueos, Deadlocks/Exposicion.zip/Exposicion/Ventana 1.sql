
--Se ejecuta primero ventana 1  y luego ventana 2 


--PROBLEMA 1: CONCURRENCIA SIN CONTROL  (ACTUALIZACI�N PERDIDA)

USE Laboratorio;
-- Asegura que est�s en la base correcta

BEGIN TRAN;
-- Inicia una transacci�n (no se guarda hasta COMMIT)

SELECT saldo FROM Cuenta WHERE id = 1;
-- Lee saldo = 1000

WAITFOR DELAY '00:00:08';
-- Espera 8 segundos (da tiempo a ejecutar la otra ventana)

UPDATE Cuenta SET saldo = 800 WHERE id = 1;
-- Cambia el saldo

COMMIT;
-- Guarda cambios
----------------------------------------------------
-- Resultado incorrecto

--Ambas transacciones leyeron el mismo valor y se sobrescribieron
select * from Cuenta;

-------------------------------------------------------------------------------
-------------------------------------------------------------------------------
--------SOLUCI�N 1: Evitar actualizaci�n perdida (UPDLOCK)------------------

--Se usa un bloqueo de actualizaci�n para que nadie m�s modifique el dato.

UPDATE Cuenta SET saldo = 1000 WHERE id = 1;  -- para poner el saldo en 1000
-----------------------------------------------

BEGIN TRAN;
-- Inicia transacci�n

SELECT saldo 
FROM Cuenta WITH (UPDLOCK);
-- Bloquea la fila para evitar que otra transacci�n la modifique

WAITFOR DELAY '00:00:08';
-- Simula tiempo de proceso

UPDATE Cuenta 
SET saldo = saldo - 200 
WHERE id = 1;
-- Actualiza correctamente

COMMIT;
-- Guarda cambios


--Resultado:  Saldo correcto = 500

--El UPDLOCK obliga a que una transacci�n espere a la otra, evitando sobrescrituras.

----------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------
--PROBLEMA 2: LECTURA SUCIA

UPDATE Cuenta SET saldo = 1000 WHERE id = 1;  -- para poner el saldo en 1000
-----------------------------------------------

BEGIN TRAN;
-- Inicia transacci�n

UPDATE Cuenta SET saldo = 200 WHERE id = 1;
-- Cambia el saldo pero NO lo confirma

--------------------------------------------
--ejecutar despues de ventana 2 para cancelar el cambio
ROLLBACK;
-- Cancela el cambio (vuelve a 1000)

---Resultado: Se ley� un dato que nunca fue definitivo----


------------------------------------------------------------------------------------
------------------------------------------------------------------------------------
--SOLUCI�N 2: Evitar lectura sucia (READ COMMITTED)

-- No permite leer datos no confirmados

BEGIN TRAN;
-- Inicia transacci�n

UPDATE Cuenta SET saldo = 200 WHERE id = 1;
-- Cambia el valor pero a�n no confirma

--Ejecutar despues de ventana 2
ROLLBACK;
-- Cancela el cambio

--Resultado:  Nunca se ley� el valor incorrecto
--READ COMMITTED evita leer datos que no est�n confirmados
--------------------------------------------------------------------------------
--------------------------------------------------------------------------------


--PROBLEMA 3: LECTURA NO REPETIBLE

UPDATE Cuenta SET saldo = 1000 WHERE id = 1;

------------------------------------------------
--Ejecucion 1
BEGIN TRAN;
-- Inicia transacci�n

SELECT saldo FROM Cuenta WHERE id = 1;  
-- Primera lectura = 1000

---------------------------------------
--Ejecutar despues de ventana 2 
SELECT saldo FROM Cuenta WHERE id = 1;
-- Segunda lectura = 800 (cambi�)

COMMIT;
-- Finaliza transacci�n
---------------------------------------

--Resultado: Consulto dos veces y obtuvo valores diferentes.

------------------------------------------------------------------------
-----------------------------------------------------------------------

--SOLUCI�N 3: Evitar lectura no repetible (REPEATABLE READ)

--Mantiene bloqueados los datos le�dos.

SET TRANSACTION ISOLATION LEVEL REPEATABLE READ;
-- Evita que otros cambien los datos le�dos

BEGIN TRAN;

SELECT saldo FROM Cuenta WHERE id = 1;
-- Lee el dato y lo bloquea


--ejecutar despues de ventana 2
SELECT saldo FROM Cuenta WHERE id = 1;
-- Sigue siendo el mismo valor

COMMIT;
-- Libera el bloqueo

--Resultado: El valor no cambia dentro de la transacci�n
--REPEATABLE READ asegura que los datos no cambien mientras los est�s usando
----------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------



-----------------PROBLEMA 4: DEADLOCK-----------------------------------------

INSERT INTO Cuenta VALUES (2, 1000); --inserta en la cuenta 2 
-------------------------------------------

BEGIN TRAN;
-- Inicia transacci�n

UPDATE Cuenta SET saldo = saldo - 100 WHERE id = 1;
-- Bloquea fila 1

WAITFOR DELAY '00:00:08';
-- Espera

UPDATE Cuenta SET saldo = saldo - 50 WHERE id = 2;
-- Intenta acceder a fila 2


--SQL Server muestra error de deadlock
----Cada transacci�n tiene un recurso y espera el otro. El sistema cancela una

-------------------------------------------------------------------------------------
------------------------------------------------------------------------------------

-----------------------SOLUCI�N 4: Evitar deadlock (orden consistente)---------------

--La clave es acceder a los datos en el mismo orden.

BEGIN TRAN;

UPDATE Cuenta SET saldo = saldo - 100 WHERE id = 1;
-- Primero accede a la cuenta 1

WAITFOR DELAY '00:00:05';

UPDATE Cuenta SET saldo = saldo - 50 WHERE id = 2;
-- Luego accede a la cuenta 2

COMMIT;

--Resultado: No hay deadlock
--Si todas las transacciones acceden en el mismo orden, se evita el bloqueo mutuo


